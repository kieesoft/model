-- MySQL dump 10.13  Distrib 5.5.46, for Win64 (x86)
--
-- Host: localhost    Database: model_tp5
-- ------------------------------------------------------
-- Server version	5.5.46-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `action`
--

DROP TABLE IF EXISTS `action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `action` varchar(45) NOT NULL COMMENT '详细动作',
  `description` varchar(45) NOT NULL COMMENT '操作名称',
  `image` varchar(20) DEFAULT 'icon-cancel' COMMENT '图标',
  `parentid` int(10) unsigned DEFAULT '0' COMMENT '上层节点',
  `ismenu` tinyint(1) DEFAULT '0' COMMENT '是否目录',
  `rank` int(11) DEFAULT '0',
  `shortname` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=231 DEFAULT CHARSET=utf8 COMMENT='操作权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action`
--

LOCK TABLES `action` WRITE;
/*!40000 ALTER TABLE `action` DISABLE KEYS */;
INSERT INTO `action` VALUES (1,' ','根目录','icon-blank',0,1,0,''),(17,'/admin/index/index','系统管理','icon-system',230,1,1,'管理'),(18,'/admin/index/action','权限分配','icon-work',17,1,0,''),(19,'/admin/index/log','操作日志','icon-log',17,1,6,''),(20,'/admin/index/user','用户管理','icon-change',17,1,2,''),(32,'/admin/index/school','院系管理','icon-home',17,1,3,''),(66,'/admin/action/query','读取动作信息','icon-blank',18,0,0,''),(67,'/admin/action/update',' 增加、删除、更新动作','icon-blank',18,0,0,''),(69,'/admin/user/query','读取用户列表','icon-blank',20,0,0,''),(70,'/admin/user/update','增加、删除、更新用户','icon-blank',20,0,0,''),(71,'/admin/user/role','读取某用户分配的角色','icon-blank',20,0,0,''),(72,'/admin/user/updaterole','增加、删除、更新用户角色','icon-change',20,0,0,''),(73,'/admin/user/changepassword','更改指定用户密码','icon-blank',20,0,0,''),(74,'/admin/school/query','读取院系信息','icon-blank',32,0,0,''),(75,'/admin/school/update','增加、删除、更新院系','icon-blank',32,0,0,''),(76,'/admin/log/query','查看日志信息','icon-blank',19,0,0,''),(77,'/admin/log/delete','清空日志','icon-blank',19,0,0,''),(172,'/home/index/index','首页','icon-home',1,0,0,''),(173,'/home/index/changepwd','进入修改密码页','icon-blank',172,0,0,''),(175,'/admin/action/role','读取某动作分配的角色','icon-blank',18,0,0,''),(176,'/admin/action/updaterole','增加、删除、更新动作的角色','icon-blank',18,0,0,''),(194,'/admin/index/role','角色管理','icon-role',17,1,3,''),(195,'/admin/role/query','读取角色信息','icon-blank',194,0,0,''),(196,'/admin/role/update','增加、更新、删除角色','icon-blank',194,0,0,''),(229,'/admin/user/getrole','获取角色','icon-blank',194,0,0,''),(230,' ','系统管理','icon-system',1,1,1,' ');
/*!40000 ALTER TABLE `action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `actionrole`
--

DROP TABLE IF EXISTS `actionrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actionrole` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `actionid` int(10) unsigned NOT NULL,
  `role` char(1) NOT NULL,
  `access` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=734 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actionrole`
--

LOCK TABLES `actionrole` WRITE;
/*!40000 ALTER TABLE `actionrole` DISABLE KEYS */;
INSERT INTO `actionrole` VALUES (698,1,'A',1),(699,17,'A',1),(700,18,'A',3),(701,19,'A',1),(702,20,'A',1),(703,32,'A',1),(704,66,'A',1),(705,67,'A',15),(706,69,'A',1),(707,70,'A',15),(708,71,'A',1),(709,72,'A',1),(710,73,'A',3),(711,74,'A',1),(712,75,'A',15),(713,76,'A',1),(714,77,'A',1),(715,172,'A',1),(716,173,'A',3),(717,175,'A',5),(718,176,'A',15),(719,194,'A',1),(720,195,'A',1),(721,196,'A',15),(722,229,'A',1),(729,230,'*',1),(731,175,'B',1),(732,175,'*',1),(733,175,'D',1);
/*!40000 ALTER TABLE `actionrole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `icon`
--

DROP TABLE IF EXISTS `icon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `icon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `icon`
--

LOCK TABLES `icon` WRITE;
/*!40000 ALTER TABLE `icon` DISABLE KEYS */;
INSERT INTO `icon` VALUES (1,'icon-tip'),(2,'icon-system'),(3,'icon-work'),(4,'icon-log'),(5,'icon-change'),(7,'icon-role'),(8,'icon-blank'),(9,'icon-add'),(10,'icon-edit'),(11,'icon-remove'),(12,'icon-save'),(13,'icon-cut'),(14,'icon-ok'),(15,'icon-no'),(16,'icon-cancel'),(17,'icon-reload'),(18,'icon-search'),(19,'icon-print'),(20,'icon-help'),(21,'icon-undo'),(22,'icon-redo'),(23,'icon-back'),(24,'icon-sum'),(25,'icon-tip'),(26,'icon-shield'),(27,'icon-free'),(28,'icon-manage'),(29,'icon-audit'),(30,'icon-home'),(31,'icon-dict'),(32,'icon-exit');
/*!40000 ALTER TABLE `icon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'guid 值',
  `host` varchar(30) NOT NULL,
  `username` varchar(9) NOT NULL COMMENT '用户号',
  `name` varchar(10) DEFAULT NULL COMMENT '姓名',
  `role` varchar(45) DEFAULT NULL COMMENT '角色',
  `operate` varchar(20) DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL COMMENT '动作',
  `remoteip` varchar(15) DEFAULT NULL COMMENT '来源IP',
  `data` varchar(1000) DEFAULT NULL,
  `requesttime` datetime DEFAULT NULL COMMENT '请求时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `logid_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=338 DEFAULT CHARSET=utf8 COMMENT='日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
INSERT INTO `log` VALUES (312,'http://localhost','kiee','方仁富','AB*','R','/web/admin/index/user','0.0.0.0','[]','2016-06-05 21:10:48'),(313,'http://localhost','kiee','方仁富','AB*','R','/web/Admin/User/query','0.0.0.0','{\"page\":\"1\",\"rows\":\"30\"}','2016-06-05 21:10:48'),(314,'http://localhost','kiee','方仁富','AB*','R','/web/Admin/User/role','0.0.0.0','[]','2016-06-05 21:10:48'),(315,'http://localhost','kiee','方仁富','AB*','R','/web/Admin/User/query','0.0.0.0','{\"name\":\"%\",\"username\":\"a%\",\"school\":\"\",\"page\":\"1\",\"rows\":\"30\"}','2016-06-05 21:10:53'),(316,'http://localhost','kiee','方仁富','AB*','R','/web/Admin/User/query','0.0.0.0','{\"name\":\"%\",\"username\":\"k%\",\"school\":\"\",\"page\":\"1\",\"rows\":\"30\"}','2016-06-05 21:10:58'),(317,'http://localhost','kiee','方仁富','AB*','R','/web/admin/index/log','0.0.0.0','[]','2016-06-05 21:26:06'),(318,'http://localhost','kiee','方仁富','AB*','R','/web/admin/index/log','0.0.0.0','[]','2016-06-05 21:27:12'),(319,'http://localhost','kiee','方仁富','AB*','R','/web/admin/index/log','0.0.0.0','[]','2016-06-05 21:27:58'),(320,'http://localhost','kiee','方仁富','AB*','R','/web/admin/','0.0.0.0','[]','2016-06-05 21:32:30'),(321,'http://localhost','kiee','方仁富','AB*','R','/web/admin/index/log','0.0.0.0','[]','2016-06-05 21:32:32'),(322,'http://localhost','kiee','方仁富','AB*','R','/web/admin/index/log','0.0.0.0','[]','2016-06-05 21:34:32'),(323,'http://localhost','kiee','方仁富','AB*','R','/web/admin/index/user','0.0.0.0','[]','2016-06-05 21:34:44'),(324,'http://localhost','kiee','方仁富','AB*','R','/web/Admin/User/query','0.0.0.0','{\"page\":\"1\",\"rows\":\"30\"}','2016-06-05 21:34:44'),(325,'http://localhost','kiee','方仁富','AB*','R','/web/Admin/User/role','0.0.0.0','[]','2016-06-05 21:34:44'),(326,'http://localhost','kiee','方仁富','AB*','R','/web/admin/index/role','0.0.0.0','[]','2016-06-05 21:34:46'),(327,'http://localhost','kiee','方仁富','AB*','R','/web/Admin/Role/query','0.0.0.0','{\"page\":\"1\",\"rows\":\"20\"}','2016-06-05 21:34:47'),(328,'http://localhost','kiee','方仁富','AB*','R','/web/admin/index/log','0.0.0.0','[]','2016-06-05 21:34:51'),(329,'http://localhost','kiee','方仁富','AB*','R','/web/admin/index/school','0.0.0.0','[]','2016-06-05 21:34:58'),(330,'http://localhost','kiee','方仁富','AB*','R','/web/Admin/School/query','0.0.0.0','{\"page\":\"1\",\"rows\":\"20\"}','2016-06-05 21:34:59'),(331,'http://localhost','kiee','方仁富','AB*','R','/web/admin/','0.0.0.0','[]','2016-06-05 21:35:11'),(332,'http://localhost','kiee','方仁富','AB*','R','/web/admin/index/user','0.0.0.0','[]','2016-06-05 21:35:13'),(333,'http://localhost','kiee','方仁富','AB*','R','/web/Admin/User/query','0.0.0.0','{\"page\":\"1\",\"rows\":\"30\"}','2016-06-05 21:35:14'),(334,'http://localhost','kiee','方仁富','AB*','R','/web/Admin/User/role','0.0.0.0','[]','2016-06-05 21:35:14'),(335,'http://localhost','kiee','方仁富','AB*','R','/web/admin/index/role','0.0.0.0','[]','2016-06-05 21:35:15'),(336,'http://localhost','kiee','方仁富','AB*','R','/web/Admin/Role/query','0.0.0.0','{\"page\":\"1\",\"rows\":\"20\"}','2016-06-05 21:35:15'),(337,'http://localhost','kiee','方仁富','AB*','R','/web/admin/index/log','0.0.0.0','[]','2016-06-05 21:35:16');
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `role` char(1) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES ('*','来宾1'),('A','系统管理员121'),('B','普通教师'),('D','学院管理员'),('H','测试数据');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schools`
--

DROP TABLE IF EXISTS `schools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schools` (
  `school` char(2) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `manage` tinyint(4) DEFAULT '0',
  `active` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`school`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schools`
--

LOCK TABLES `schools` WRITE;
/*!40000 ALTER TABLE `schools` DISABLE KEYS */;
INSERT INTO `schools` VALUES ('01','商贸学院',0,0),('02','人文学院',0,0),('03','信息学院',0,1),('A1','教务处1',0,1);
/*!40000 ALTER TABLE `schools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `username` varchar(20) NOT NULL,
  `sessionid` varchar(45) DEFAULT NULL,
  `remoteip` varchar(15) DEFAULT NULL,
  `logintime` datetime DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('kiee','{CED1EADA-C0E5-5861-03E0-8813-3997370E}','192.168.1.100','2016-06-05 22:29:14');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sexcode`
--

DROP TABLE IF EXISTS `sexcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sexcode` (
  `code` char(1) NOT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sexcode`
--

LOCK TABLES `sexcode` WRITE;
/*!40000 ALTER TABLE `sexcode` DISABLE KEYS */;
INSERT INTO `sexcode` VALUES ('F','女'),('M','男');
/*!40000 ALTER TABLE `sexcode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teachers`
--

DROP TABLE IF EXISTS `teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teachers` (
  `teacherno` char(6) NOT NULL,
  `name` varchar(10) DEFAULT NULL,
  `enteryear` char(4) DEFAULT NULL,
  `school` char(2) DEFAULT NULL,
  `sex` char(1) DEFAULT NULL,
  PRIMARY KEY (`teacherno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teachers`
--

LOCK TABLES `teachers` WRITE;
/*!40000 ALTER TABLE `teachers` DISABLE KEYS */;
INSERT INTO `teachers` VALUES ('A11004','方仁富','2014','A1','M');
/*!40000 ALTER TABLE `teachers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `username` varchar(20) NOT NULL,
  `teacherno` char(6) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `roles` varchar(45) DEFAULT NULL,
  `lock` tinyint(4) DEFAULT '0',
  `createdate` datetime DEFAULT NULL,
  PRIMARY KEY (`username`),
  UNIQUE KEY `teacherno_UNIQUE` (`teacherno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('kiee','A11004','123456','AB*',0,'2015-01-01 00:00:00');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-05 22:34:49
